package com.example.listycity;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.EditText;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.DialogFragment;

import java.util.ArrayList;

public class EditCityFragment extends DialogFragment {

    private EditText cityName_box;
    private EditText provinceName_box;
    private City current_city;
    private OnFragmentInteractionListener listener;

    public void setCityInfo(ArrayList<City> list, int i){
        // Create variables for the given city's information
        current_city = list.get(i);
    }

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        if (context instanceof OnFragmentInteractionListener) {
            listener = (OnFragmentInteractionListener) context;
        }
        else {
            throw new RuntimeException(context.toString() + "OnFragmentInteractionListener is not implemented.");
        }
    }

    public interface OnFragmentInteractionListener {
        void onUpdatePressed(City old_city, City new_city);
    }

    @NonNull
    @Override
    public Dialog onCreateDialog(@Nullable Bundle savedInstanceState) {
        View view = LayoutInflater.from(getActivity()).inflate(R.layout.add_city_fragment_layout, null);

        cityName_box = view.findViewById(R.id.city_name_edit_text);
        provinceName_box = view.findViewById(R.id.province_name_edit_text);

        cityName_box.setText(current_city.getName());
        provinceName_box.setText(current_city.getProvince());

        AlertDialog.Builder builder = new AlertDialog.Builder(getContext());

        return builder
                .setView(view)
                .setTitle("Edit City")
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Update", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        String name = cityName_box.getText().toString();
                        String province = provinceName_box.getText().toString();

                        listener.onUpdatePressed(current_city, new City(name, province));
                    }
                }).create();
    }
}