package com.example.kestacio_expbook;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.EditText;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.DialogFragment;

public class AddExpensePopup extends DialogFragment {
    // Class for creating a popup dialog when the user clicks "Add Expense"

    private OnFragmentInteractionListener listener;
    private EditText expense_name_box;
    private EditText expense_charge_box;
    private EditText expense_year_box;
    private EditText expense_month_box;
    private EditText expense_comment_box;

    @Override
    public void onAttach(@NonNull Context context) {
        // Make sure the activity implements the interface for the listener
        super.onAttach(context);
        if (context instanceof OnFragmentInteractionListener) {
            listener = (OnFragmentInteractionListener) context;
        }
        else {
            throw new RuntimeException(context + "OnFragmentInteractionListener is not implemented.");
        }
    }

    public interface OnFragmentInteractionListener {
        // Interface for the listener
        void onAddPressed(Expense expense);
    }

    @NonNull
    @Override
    public Dialog onCreateDialog(@Nullable Bundle savedInstanceState) {
        // Create a blank expense popup dialog
        View view = LayoutInflater.from(getActivity()).inflate(R.layout.expense_edit_popup, null);

        // Find each EditText box on the fragment
        expense_name_box = view.findViewById(R.id.expense_name_box);
        expense_comment_box = view.findViewById(R.id.expense_comment_box);
        expense_charge_box = view.findViewById(R.id.expense_charge_box);
        expense_year_box = view.findViewById(R.id.expense_year_box);
        expense_month_box = view.findViewById(R.id.expense_month_box);

        AlertDialog.Builder builder = new AlertDialog.Builder(getContext());

        return builder
                .setView(view)
                .setTitle("Add Expense")
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Add", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        // If the user clicks the "Add" button

                        // Take each user input
                        String name = expense_name_box.getText().toString();
                        String charge = expense_charge_box.getText().toString();
                        String comment = expense_comment_box.getText().toString();
                        String year = expense_year_box.getText().toString();
                        String month = expense_month_box.getText().toString();

                        // If all user inputs match the input criteria, add the input to the expense list
                        // Otherwise, cancel the dialog action
                        if (name.length() > 0 && charge.length() > 0 && year.length() == 4 && Integer.parseInt(year) >= 1900 && Integer.parseInt(year) <= 2024 && month.length() > 0 && Integer.parseInt(month) <= 12)
                            listener.onAddPressed(new Expense(name, Double.parseDouble(charge), Integer.parseInt(year), Integer.parseInt(month), comment));
                    }
                }).create();
    }
}
