package com.example.kestacio_expbook;

public class Expense {
    // Class for an Expense object

    private String name;
    private double charge;
    private int year;
    private int month;
    private String comment;

    public Expense(String name, double charge, int year, int month) {
        // Constructor for Expense if comment isn't given
        this.name = name;
        this.charge = charge;
        this.year = year;
        this.month = month;
        this.comment = "";
    }

    public Expense(String name, double charge, int year, int month, String comment) {
        // Constructor for Expense if comment is given
        this.name = name;
        this.charge = charge;
        this.year = year;
        this.month = month;
        this.comment = comment;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        if (name.length() >= 1 && name.length() <= 15)
            this.name = name;
    }

    public double getCharge() {
        return charge;
    }

    public void setCharge(double charge) {
        if (charge >= 0.00)
            this.charge = charge;
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        if (year >= 1900 && year <= 2024)
            this.year = year;
    }

    public int getMonth() {
        return month;
    }

    public void setMonth(int month) {
        if (month >= 1 && month <= 12)
            this.month = month;
    }

    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        if (comment.length() <= 20)
            this.comment = comment;
    }
}
