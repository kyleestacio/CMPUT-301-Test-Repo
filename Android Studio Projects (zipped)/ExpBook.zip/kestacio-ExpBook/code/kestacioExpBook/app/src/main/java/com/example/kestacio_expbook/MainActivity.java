package com.example.kestacio_expbook;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity implements AddExpensePopup.OnFragmentInteractionListener, EditExpensePopup.OnFragmentInteractionListener {
    // Create an app for users to manage their expenses

    // Issues:
    // - When an expense is clicked on, it does not permanently show that it is clicked
    // - When an expense is deleted, clicking "view/edit expense" without clicking on a new expense crashes the app


    private ListView expense_list_view;
    private ArrayList<Expense> expense_list;
    private ArrayAdapter<Expense> expense_array_adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        // Set view to the main screen
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        expense_list = new ArrayList<>();

        // Create an ArrayAdapter for the ListView
        expense_list_view = findViewById(R.id.expense_list_view);
        expense_array_adapter = new ExpenseArrayAdapter(this, expense_list);
        expense_list_view.setAdapter(expense_array_adapter);

        updateTotalSum();
    }

    @SuppressLint({"SetTextI18n", "DefaultLocale"})
    protected void updateTotalSum() {
        TextView total = findViewById(R.id.total_charges);
        double current_total = 0.0;

        // Calculate the total charge for all expenses
        for (int i = 0; i < expense_list.size(); i++) {
            Expense expense = expense_list.get(i);
            double expense_charge = expense.getCharge();
            current_total = current_total + expense_charge;
        }
        total.setText(String.format("%.2f", current_total));
    }

    @Override
    protected void onResume() {
        super.onResume();

        // Check if the user clicks the "add expense" button
        Button add_expense_button = findViewById(R.id.add_new_expense_button);
        add_expense_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // If the user clicks "add expense", open the add expense popup
                new AddExpensePopup().show(getSupportFragmentManager(), "Add_Expense");
            }
        });

        // Check if the user clicks on an expense
        expense_list_view.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {

                // Check if the user clicks on "delete expense" after clicking on an expense
                Button delete_expense_button = findViewById(R.id.delete_expense_button);
                delete_expense_button.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        // If user clicks "delete expense" button after clicking an expense,
                        // Delete the expense from the expense list
                        Expense expense = expense_list.get(i);
                        expense_array_adapter.remove(expense);
                        updateTotalSum();
                        view.setOnClickListener(null);
                    }
                });

                // Check if the user clicks on "view/edit expense" after clicking on an expense
                Button view_and_edit_expense_button = findViewById(R.id.view_edit_expense_button);
                view_and_edit_expense_button.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        // If user clicks "view/edit expense" button after clicking an expense,
                        // Open the edit expense popup with the current expense's information
                            EditExpensePopup popup = new EditExpensePopup();
                            popup.setExpenseInfo(expense_list, i);
                            popup.show(getSupportFragmentManager(), "Edit_Expense");
                            view.setOnClickListener(null);
                    }
                });
            }
        });

    }

    @Override
    public void onAddPressed(Expense expense) {
        // Add the given expense to the expense list
        expense_list.add(expense);
        expense_array_adapter.notifyDataSetChanged();
        updateTotalSum();
    }

    @Override
    public void onUpdatePressed(Expense old_expense, Expense new_expense) {
        // Delete the old expense, add the updated expense
        int i = expense_array_adapter.getPosition(old_expense);
        expense_array_adapter.remove(old_expense);
        expense_array_adapter.insert(new_expense, i);
        expense_array_adapter.notifyDataSetChanged();
        updateTotalSum();
    }
}