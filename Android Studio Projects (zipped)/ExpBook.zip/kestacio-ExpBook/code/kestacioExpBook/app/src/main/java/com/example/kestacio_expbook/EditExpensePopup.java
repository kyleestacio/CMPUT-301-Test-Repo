package com.example.kestacio_expbook;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.EditText;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.DialogFragment;

import java.util.ArrayList;
import java.util.Objects;

public class EditExpensePopup extends DialogFragment {
    // Class for creating a popup dialog when the user clicks "View/Edit Expense"

    private OnFragmentInteractionListener listener;
    private EditText expense_name_box;
    private EditText expense_charge_box;
    private EditText expense_year_box;
    private EditText expense_month_box;
    private EditText expense_comment_box;
    private Expense current_expense;

    public void setExpenseInfo(ArrayList<Expense> list, int i){
        // Create variables for the given expense's information
        current_expense = list.get(i);
    }

    @Override
    public void onAttach(@NonNull Context context) {
        // Make sure the activity implements the interface for the listener
        super.onAttach(context);
        if (context instanceof OnFragmentInteractionListener) {
            listener = (OnFragmentInteractionListener) context;
        }
        else {
            throw new RuntimeException(context + "OnFragmentInteractionListener is not implemented.");
        }
    }

    public interface OnFragmentInteractionListener {
        // Interface for the listener
        void onUpdatePressed(Expense old_expense, Expense new_expense);
    }

    @SuppressLint("SetTextI18n")
    @NonNull
    @Override
    public Dialog onCreateDialog(@Nullable Bundle savedInstanceState) {
        // Create an edit expense dialog with the current expense's information
        View view = LayoutInflater.from(getActivity()).inflate(R.layout.expense_edit_popup, null);

        // Find each EditText box on the fragment
        expense_name_box = view.findViewById(R.id.expense_name_box);
        expense_comment_box = view.findViewById(R.id.expense_comment_box);
        expense_charge_box = view.findViewById(R.id.expense_charge_box);
        expense_year_box = view.findViewById(R.id.expense_year_box);
        expense_month_box = view.findViewById(R.id.expense_month_box);

        // Fill in the EditText boxes with the current expense's information (as strings)
        expense_name_box.setText(current_expense.getName());
        expense_comment_box.setText(current_expense.getComment());
        expense_charge_box.setText(Double.toString(current_expense.getCharge()));
        expense_year_box.setText(Integer.toString(current_expense.getYear()));
        expense_month_box.setText(Integer.toString(current_expense.getMonth()));

        AlertDialog.Builder builder = new AlertDialog.Builder(getContext());

        return builder
                .setView(view)
                .setTitle("View/Edit Expense")
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Update", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        // If user clicks update
                        String name = expense_name_box.getText().toString();
                        String charge = expense_charge_box.getText().toString();
                        String comment = expense_comment_box.getText().toString();
                        String year = expense_year_box.getText().toString();
                        String month = expense_month_box.getText().toString();

                        // If user input matches all input criteria, check to see if expense needs update
                        // Otherwise, cancel the action
                        if (name.length() > 0 && charge.length() > 0 && year.length() == 4 && Integer.parseInt(year) <= 2023 && month.length() > 0 && Integer.parseInt(month) <= 12) {
                            listener.onUpdatePressed(current_expense, new Expense(name, Double.parseDouble(charge), Integer.parseInt(year), Integer.parseInt(month), comment));
                        }
                    }
                }).create();
    }
}