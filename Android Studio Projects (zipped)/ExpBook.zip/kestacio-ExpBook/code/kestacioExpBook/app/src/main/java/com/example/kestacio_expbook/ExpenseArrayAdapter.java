package com.example.kestacio_expbook;

import android.annotation.SuppressLint;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.ArrayList;

public class ExpenseArrayAdapter extends ArrayAdapter<Expense> {
    // Class for creating a custom ArrayAdapter for the Expense class

    private final ArrayList<Expense> expense_list;
    private final Context context;

    public ExpenseArrayAdapter(Context context, ArrayList<Expense> expense_list) {
        // Constructor for the adapter
        super(context, 0, expense_list);
        this.context = context;
        this.expense_list = expense_list;
    }

    @SuppressLint({"SetTextI18n", "DefaultLocale"})
    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        // Set values for each view in the Listview
        View view = convertView;

        if (view == null) {
            view = LayoutInflater.from(context).inflate(R.layout.expense, parent, false);
        }

        // Get the TextViews for each element of the expense view
        Expense expense = expense_list.get(position);
        TextView expense_name = view.findViewById(R.id.expense_name);
        TextView expense_charge = view.findViewById(R.id.expense_charge);
        TextView expense_year = view.findViewById(R.id.expense_year);
        TextView expense_month = view.findViewById(R.id.expense_month);
        TextView expense_comment = view.findViewById(R.id.expense_comment);

        // Assign each TextView to the specific values of the expense (converted to strings if needed)
        expense_name.setText(expense.getName());
        expense_charge.setText(String.format("%.2f", expense.getCharge())); // show w/ 2 decimals
        expense_year.setText(Integer.toString(expense.getYear()));
        expense_comment.setText(expense.getComment());

        // Assign the TextView for the data
        if (expense.getMonth() >= 10) {
            // If month is 10-12, simply put it as the month
            expense_month.setText(Integer.toString(expense.getMonth()));
        }
        else {
            // If month is 1-9, add a '0' before it
            String month_string = Integer.toString(expense.getMonth());
            expense_month.setText("0" + month_string);
        }

        return view;
    }
}
