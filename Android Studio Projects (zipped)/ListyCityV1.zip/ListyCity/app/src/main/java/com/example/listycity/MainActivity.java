package com.example.listycity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.InputType;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    ListView cityList;
    ArrayAdapter<String> cityAdapter;
    ArrayList<String> dataList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Set the view of the app to the activity_main page
        setContentView(R.layout.activity_main);

        // Get the ListView view
        cityList = findViewById(R.id.city_list);

        // Add list of default cities to a data list
        String[] cities = {"Edmonton", "Vancouver", "Moscow", "Sydney", "Berlin", "Vienna", "Tokyo", "Beijing", "Osaka", "New Delhi"};
        dataList = new ArrayList<>();
        dataList.addAll(Arrays.asList(cities));

        // Create an ArrayAdapter to put each city in the data list into a single data box
        cityAdapter = new ArrayAdapter<>(this, R.layout.my_new_layout, dataList);
        // Set the ListView data to the city boxes
        cityList.setAdapter(cityAdapter);
    }

    @Override
    protected void onStart() {
        super.onStart();
    }

    @Override
    protected void onResume() {
        super.onResume();

        Button add_city_button = findViewById(R.id.add_city);
        add_city_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                EditText text_box = findViewById(R.id.edit_text);
                String user_input = text_box.getText().toString();
                if (user_input.length() > 0)
                    cityAdapter.add(user_input);
            }
        });
        
        cityList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                String clicked_city = (String) cityList.getItemAtPosition(i);

                Button delete_city_button = findViewById(R.id.delete_city);
                delete_city_button.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        cityAdapter.remove(clicked_city);
                    }
                });
            }
        });
    }

    @Override
    protected void onPause() {
        super.onPause();
    }

    @Override
    protected void onStop() {
        super.onStop();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }
}
