package com.example.listycity;

import java.sql.Array;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * This is the class that keeps track of a list of City objects.
 */

public class CityList {
    /**
     * City object storage
     */
    private List<City> cities = new ArrayList<>();

    /**
     * Add a new city to the list, if the city does not exist in the list already
     * @param city the candidate city to be added
     * @throws IllegalArgumentException if the list contains the city
     */
    public void add(City city) {
        if (cities.contains(city)) {
            throw new IllegalArgumentException("Error: duplicate entry.");
        }
        cities.add(city);
    }

    /**
     * Returns a sorted list of cities
     * @return a sorted list of cities
     */
    public List<City> getCities() {
        List<City> list = cities;
        Collections.sort(list);
        return cities;
    }

    /**
     * When given a city, return whether or not it belongs in the list already.
     * @param city the city to be tested whether or not it is in the list
     * @return true if the list contains the given city
     */
    public boolean hasCity(City city) {
        return cities.contains(city);
    }

    /**
     * Removes a city from the list. Throws an exception if the city does not exist in the list.
     * @param city the city to be deleted
     */
    public void delete(City city) {
        if (cities.contains(city)) {
            cities.remove(city);
        }
        else {
            throw new IllegalArgumentException("Error: no such entry.");
        }
    }

    /**
     * Returns how many cities are in the list
     * @return the number of cities in the list
     */
    public int countCities() {
        return cities.size();
    }
}
