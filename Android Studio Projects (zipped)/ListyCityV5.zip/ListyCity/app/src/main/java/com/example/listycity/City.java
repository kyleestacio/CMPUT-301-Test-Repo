package com.example.listycity;

public class City implements Comparable<City> {
    private String name;
    private String province;

    /**
     * Create a new city object
     * @param name name of city
     * @param province name of province
     */
    public City(String name, String province) {
        this.name = name;
        this.province = province;
    }

    /**
     * Get the name of the city
     * @return the name of the city
     */
    public String getName() {
        return name;
    }

    /**
     * Set the name of the city
     * @param name the name to set the city name to
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * Get the name of the city's province
     * @return the name of the city's province
     */
    public String getProvince() {
        return province;
    }

    /**
     * Set the name of the city's province
     * @param province the name to set the city's province to
     */
    public void setProvince(String province) {
        this.province = province;
    }

    /**
     * Compare the city to another given city object.
     * @param city the object to be compared.
     * @return return 0 if the two compared cities are the same, a different value otherwise.
     */
    @Override
    public int compareTo(City city) {
        return name.compareTo(city.getName());
    }
}
